#' A BRMS model fit estimating the dry weight (mg) by intertegular distance (mm), sex and taxonomic family for ~400 bee species.
#'
"bee_tax_mod"