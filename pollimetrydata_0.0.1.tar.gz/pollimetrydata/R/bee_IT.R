#' A BRMS model fit estimating the dry weight (mg) by intertegular distance (mm) for ~400 bee species.
#'
"bee_IT"