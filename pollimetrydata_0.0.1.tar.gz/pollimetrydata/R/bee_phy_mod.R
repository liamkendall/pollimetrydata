#' A BRMS model fit estimating the dry weight (mg) by intertegular distance (mm), sex and phylogeny for ~400 bee species.
#'
"bee_phy_mod"