#' A BRMS model fit estimating the dry weight (mg) by intertegular distance (mm), sex and taxonomic subfamily for ~100 hoverfly species.
#'
"hov_tax_mod"